create database assignmentgroup;
use assignmentgroup;
create table table1(id int,Name_ Varchar(100),age int);
insert into table1 values(1,"Bob",21),(2,"Sam",19),(3,"Jill",18),(4,"Jim",21),(5,"Sally",19),(6,"Jess",20),(7,"Will",21);
select * from table1;
select age,count(age) from table1 group by age ;
